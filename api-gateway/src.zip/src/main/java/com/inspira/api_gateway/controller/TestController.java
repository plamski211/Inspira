package com.inspira.api_gateway.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
public class TestController {
    private static final Logger logger = LoggerFactory.getLogger(TestController.class);

    @GetMapping("/public/test")
    public Mono<String> publicTest() {
        return Mono.just("This is a public endpoint that doesn't require authentication");
    }

    @GetMapping("/private/test")
    public Mono<String> privateTest(@AuthenticationPrincipal Jwt jwt) {
        logger.info("Received JWT with subject: {}", jwt.getSubject());
        logger.info("JWT claims: {}", jwt.getClaims());

        return Mono.just("You are authenticated! Subject: " + jwt.getSubject());
    }
}
